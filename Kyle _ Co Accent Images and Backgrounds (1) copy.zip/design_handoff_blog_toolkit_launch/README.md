# Handoff: Blog — "We Built the Foundation. Now Here It Is."

> **Toolkit Launch blog post for the HCAIC website**

---

## Overview

This package contains a complete, ready-to-publish blog post announcing the launch of the **HCAIC Transformation Toolkit**. It's the first long-form piece of content in the campaign, written to sit on the HCAIC website (`hcaic.kyleandco.com` / wherever the new webpage is deployed) alongside the existing pages like `change-management.html`, `solution-decision.html`, `toolkit-signup.html`, etc.

The post:
- Introduces the four-resource toolkit
- Names the council members who led each resource (with photos)
- Pitches the "Year Two" Council momentum
- Ends with three CTAs: access the toolkit, register for the town hall, apply to join the Council

---

## About the design files

The HTML file in this bundle (`blog-toolkit-launch.html`) is **production-ready, not a design reference**. It was written in the same vanilla HTML/CSS pattern as the existing HCAIC pages (`change-management.html`, `solution-decision.html`, `toolkit-signup.html`) — same CSS variables, same `Helvetica Neue` font stack, same `.topbar` / `.page-footer` chrome, same fade-in `IntersectionObserver` script.

You should be able to **drop this file directly into the `HCAIC new webpage/` folder** and it will work alongside the rest of the site. No build step. No framework. No new dependencies.

The supporting images live in `blog-assets/` (relative path — keep this folder structure intact).

## Fidelity

**High-fidelity / production-ready.** Final colors, typography, spacing, copy, and assets. The only thing the developer needs to do is:

1. Copy the file in
2. Verify the link targets (see "Things to verify before publishing" below)
3. Push

---

## File structure

```
design_handoff_blog_toolkit_launch/
├── README.md                       ← you are here
├── blog-toolkit-launch.html        ← the blog page (drop into website root)
└── blog-assets/                    ← drop into website root alongside the HTML
    ├── blog-hero.png               ← 1600×656  (hero banner)
    ├── blog-kyle-quote.png         ← 1600×1088 (optional pull-quote, currently hidden)
    ├── blog-full-toolkit.png       ← 1600×1088 (visual TOC after intro)
    ├── blog-literacy.png           ← 1600×1088
    ├── blog-change-mgmt.png        ← 1600×1088
    ├── blog-solution.png           ← 1600×1088
    ├── blog-responsible.png        ← 1600×1088
    ├── headshot-rachel-bourne.jpg
    ├── headshot-melissa-laswell.jpg
    ├── headshot-alicia-miller.jpg
    ├── headshot-lydia-wu.jpeg      ← note: .jpeg extension (the only one)
    ├── headshot-susan-jackson.jpg
    └── headshot-tara-torres.jpg
```

The HTML file references images using the relative path `blog-assets/<filename>`. If you'd rather flatten or rename the asset folder, update those paths in the HTML.

### Image source notes

| File | Origin | Treatment |
|---|---|---|
| `blog-hero.png` | `linkedin-assets/HCAIC Email Headers/Email #1 -  HCAIC Toolkit Launch.png` | Resized to 1600 wide |
| `blog-kyle-quote.png` | `linkedin-assets/HCAIC Toolkit Pull Quotes/HCAIC Framing quote Kyle 1080x1080.png` | Cropped 14% top + 18% bottom to remove "ASSET X OF 4 / LINK IN COMMENTS" chrome and Kyle&Co watermark, scaled to 1600 wide |
| `blog-full-toolkit.png` | `linkedin-assets/Single HCAIC Asset 1080x1080 Promo/Full AI Transformation Toolkit promo.png` | Same crop |
| `blog-literacy.png` | `…/AI Education & Literacy promo.png` | Same crop |
| `blog-change-mgmt.png` | `…/Change management & adoption promo.png` | Same crop |
| `blog-solution.png` | `…/AI Solution Decision framework promo.png` | Same crop |
| `blog-responsible.png` | `…/Responsible AI framework for implementation promo.png` | Same crop |
| Headshots | `member-headshots/` | Used as-is |

The originals were sized for LinkedIn (1080×1080 with social copy and badging). The cropped versions remove that chrome so they read as editorial assets, not social posts.

---

## Page structure (top → bottom)

1. **Top nav** (`.topbar`) — matches the rest of the site exactly. Brand on left, page title in middle, "Access the Toolkit" CTA on right linking to `toolkit-signup.html`.
2. **Post meta strip** — tag pill ("Toolkit Launch") + date + read time.
3. **H1 title** — *"We Built the Foundation. Now Here It Is."* (italic in the second line uses `<em>`, lilac color).
4. **Byline** — "Kyle & Co · The Human-Centric AI Council".
5. **Hero image** — `blog-hero.png`, 1600×656, full-width inside the 760px article column.
6. **Lede paragraph + intro** — 4 paragraphs.
7. **Section: "Introducing the HCAIC Transformation Toolkit"** — 4 paragraphs + the full-toolkit grid image (`blog-full-toolkit.png`).
8. **Resource sections** (× 4) — each with a kicker (`Resource 0X`), italic h2, sec-lead caption, leader pill(s) with photo, accent image, then 2–4 paragraphs of body. Section 02 (Change Management) also includes a `.pullquote` block.
9. **"Why These Four, Why Now"** — 3 paragraphs.
10. **"What's Next"** — 4 paragraphs about Year Two.
11. **CTA block** (`.cta-block`) — navy block, three buttons: primary "Access the Toolkit", secondary "Register for Town Hall", secondary "Apply to Join HCAIC".
12. **Page footer** — matches the rest of the site.

---

## Things to verify before publishing

The HTML uses `href` values that match what's already in the codebase, but **the developer should sanity-check these before deploy**:

| Where | Current href | What to confirm |
|---|---|---|
| Top-nav brand link | `index.html` | Should land on the HCAIC homepage |
| Top-nav CTA | `toolkit-signup.html` | Should be the live toolkit gate |
| CTA "Access the Toolkit" | `toolkit-signup.html` | Same as above |
| CTA "Register for Town Hall" | `townhall-registration.html` | This file exists in the repo — confirm it's the right destination |
| CTA "Apply to Join HCAIC" | `index.html#join` | If there's no `#join` anchor on the index page, point this to the correct apply path (or add the anchor) |
| Footer "Back to The Council →" | `index.html` | Same as nav brand |

If any of those targets have changed (different filenames, different anchors, external URLs), update the href values in `blog-toolkit-launch.html`.

---

## Optional: Kyle pull-quote image

The HTML includes one **commented-out** image block (search the file for `OPTIONAL: Kyle framing pull quote image`). The associated asset (`blog-kyle-quote.png`) is shipped in case you want to surface it later — it's a 1600×1088 image of a framing quote from Kyle and would slot in between the opening and the toolkit intro. To enable, just remove the `<!-- ... -->` wrapper around that figure.

---

## Design tokens used

These are the CSS custom properties at the top of the file. They're identical to the values in `change-management.html` / `solution-decision.html` / `toolkit-signup.html`, so the post will inherit any future token changes if you decide to extract these into a shared stylesheet.

```css
--navy:       #273752;   /* primary text + nav background */
--navy-dark:  #172339;
--navy-mid:   #2D5C94;
--lilac:      #9D92AD;   /* italic accent + kickers */
--lilac-light:#C1BACD;
--ivory:      #F7F1EA;   /* page background */
--slate:      #555961;   /* muted text */
--cream:      #FDECCD;   /* CTA buttons + pull-quote tint */
```

### Typography

- **Body:** `'Helvetica Neue', Helvetica, Arial, sans-serif` (no Google Fonts — matches the rest of the site).
- **H1 weight:** `300` with `letter-spacing: -0.025em`. Italic phrases use `<em>` and inherit lilac color.
- **Lede paragraph:** `1.25rem`, navy.
- **Body paragraph:** `1.05rem`, line-height `1.75`, color `#3a4558`.
- **Section kicker** (e.g. "Resource 01"): `0.62rem`, uppercase, letter-spacing `0.2em`, lilac.
- **H2 section header:** `clamp(1.7rem, 3vw, 2.2rem)`, weight `400`, italic accents in lilac.

### Spacing

- Article column: `max-width: 760px`, horizontal padding `1.5rem` mobile / inherited above 700px.
- Article top padding: `4rem` desktop, `2.5rem` mobile.
- Hero image bottom margin: `3rem`.
- Section divider (`<hr class="rule">`): `4rem` margin top/bottom.
- Pull quote: `2.5rem` margin top/bottom, `1.5rem 2rem` padding.
- Final CTA block: `3rem` padding desktop, `2rem 1.5rem` mobile.

### Border radii

- Pill / CTA buttons: `100px`
- Image cards: `8px`
- Pull quote: `0 6px 6px 0` (left edge flush against the colored border)
- Final CTA block: `12px`
- Leader pill avatar: `50%`

### Shadows

None. The site uses background tints + thin borders rather than shadows for hierarchy.

---

## Behavior

- **`IntersectionObserver` fade-in.** Sections with class `.fade-in` start at `opacity: 0` translated 18px down, then ease in when scrolled 8% into view. Same script as `change-management.html`.
- **Smooth scroll.** `html { scroll-behavior: smooth }` is on for in-page anchor jumps (used by the top nav and footer back-link if you point them at anchors).
- **Responsive.** Single breakpoint at `700px`: hides the topbar title, tightens article padding, tightens the CTA block padding.

No state management, no data fetching, no JS frameworks. Plain HTML.

---

## SEO / metadata

The current `<head>` has only the basics — title, charset, viewport, favicon. Before publishing, add:

- `<meta name="description" content="…">`
- Open Graph tags (`og:title`, `og:description`, `og:image` pointing at `blog-assets/blog-hero.png`)
- Twitter Card tags
- Canonical URL
- Any analytics tags the rest of the site uses

I left these out because they'll be configured at the platform level (or via a shared head partial if you ever extract one).

---

## If you decide to extract a shared layout

Right now every page in the HCAIC site copies the same `:root`, `.topbar`, and `.page-footer` blocks inline. If you'd like to refactor, this blog post is a clean candidate to lead with — pull the shared CSS into `styles.css`, the topbar and footer markup into includes/partials (or whatever your platform supports), and reference them from this file. Nothing in the page-specific styles overlaps with the shared ones.

---

## Questions / contact

The image cropping logic is documented above if you ever need to regenerate the assets from updated source files. The post copy was drafted from the campaign brief — content edits should run through Kyle / the Council before publish.
